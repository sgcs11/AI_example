#__project__

##project1
-흉부 CT이미지로 코로나 감염 여부 예측

##평가지표 
-Accuaracy

##제한사항
1.외부데이터 사용불가
2.전이학습 불가
